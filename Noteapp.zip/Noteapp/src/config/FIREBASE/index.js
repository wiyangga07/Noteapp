import firebase from "firebase/compat/app";
import "firebase/compat/auth";
import "firebase/compat/firestore";
import "firebase/compat/database";

firebase.initializeApp({
  apiKey: "AIzaSyAmQoOHC7hD7HpcmYgGiCF9xV5e947ALgo",
  authDomain: "noteapp-23075.firebaseapp.com",
  projectId: "noteapp-23075",
  storageBucket: "noteapp-23075.appspot.com",
  messagingSenderId: "91383047808",
  appId: "1:91383047808:web:1e127e2a82919c57d06865"
});

const FIREBASE = firebase;

export default FIREBASE;