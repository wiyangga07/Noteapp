export * from "./besar";
export * from "./kecil";
